# GPU Graphics Programming Crash Course — Arch Linux + C++ (OpenGL)

This is a from-zero-to-triangle guide. By the end you'll have a working
OpenGL window, understand the core rendering pipeline, and have a small
CMake project you can keep building on.

---

## 1. Install what you need

OpenGL on Linux is provided by your GPU driver via Mesa (open-source) or
the proprietary NVIDIA driver. You also need a windowing/context library
(GLFW) and an OpenGL function loader (GLEW).

```bash
sudo pacman -Syu
sudo pacman -S base-devel cmake git

# Drivers — pick based on your GPU
sudo pacman -S mesa vulkan-radeon      # AMD
sudo pacman -S mesa vulkan-intel       # Intel
sudo pacman -S nvidia nvidia-utils     # NVIDIA proprietary
# (skip vulkan-* packages if you only care about OpenGL, they don't hurt though)

# Libraries for this course
sudo pacman -S glfw-x11 glew glm
```

- **GLFW** — creates the window + OpenGL context, handles input.
- **GLEW** — loads OpenGL function pointers at runtime (OpenGL itself is
  just a spec; your driver implements it, and GLEW finds those functions
  for you).
- **GLM** — header-only math library (vectors, matrices) with GLSL-like syntax.

Check your driver is alive:

```bash
glxinfo | grep "OpenGL version"   # pacman -S mesa-utils if glxinfo is missing
```

You want to see 4.x (Mesa/NVIDIA on any remotely modern GPU supports this).

---

## 2. Mental model: how the pipeline actually works

Before touching code, internalize this. GPUs are massively parallel
processors. OpenGL is a state machine you configure, then you issue a
"draw call" and the fixed pipeline below runs your data through it:

```
Your vertex data (CPU, in a buffer)
        │
        ▼
 ┌─────────────────┐
 │  Vertex Shader   │  runs once PER VERTEX, in parallel
 │  (you write it)  │  outputs a clip-space position (+ any data to pass on)
 └─────────────────┘
        │
        ▼
   Primitive Assembly + Rasterization   (fixed-function: turns triangles
        │                                into fragments/pixels — not yours to write)
        ▼
 ┌─────────────────┐
 │ Fragment Shader  │  runs once PER PIXEL covered by the triangle
 │  (you write it)  │  outputs a color
 └─────────────────┘
        │
        ▼
   Framebuffer (the image you see)
```

Everything you do in "modern" OpenGL (3.3 core and later — don't learn the
old immediate-mode `glBegin/glEnd` API, it's deprecated and teaches bad habits)
boils down to:

1. Upload vertex data to GPU memory → **VBO** (Vertex Buffer Object)
2. Describe the *layout* of that data → **VAO** (Vertex Array Object)
3. Write two small GPU programs → **shaders**, in GLSL
4. Link them into a **shader program**
5. Bind everything and call `glDrawArrays` / `glDrawElements`

That's the whole mental model. Everything else (textures, lighting, 3D
transforms, depth testing) is refinement on top of this loop.

---

## 3. Project setup

```
opengl-crash-course/
├── CMakeLists.txt
└── src/
    └── main.cpp
```

### CMakeLists.txt

See the file in this project — it finds GLFW/GLEW/OpenGL via pkg-config
and links them.

### Build & run

```bash
cd opengl-crash-course
cmake -B build
cmake --build build
./build/triangle
```

You should get a window with a colored triangle on a dark background.
Press ESC or close the window to quit.

---

## 4. Walking through `main.cpp`

The full file is in this project; here's what each part is doing.

### a) Window + context creation (GLFW)

```cpp
glfwInit();
glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

GLFWwindow* window = glfwCreateWindow(800, 600, "Triangle", nullptr, nullptr);
glfwMakeContextCurrent(window);
```

`CORE_PROFILE` disables the old deprecated fixed-function API — you're
forced to learn the shader-based way, which is what you want.

### b) Loading OpenGL functions (GLEW)

```cpp
glewExperimental = GL_TRUE;
glewInit();
```

Without this, none of the `gl*` functions beyond the ancient OpenGL 1.1 ABI
exist as usable symbols — GLEW resolves them from the driver at runtime.

### c) Vertex data → VBO + VAO

```cpp
float vertices[] = {
    // positions        // colors
     0.0f,  0.5f, 0.0f,  1.0f, 0.0f, 0.0f,
    -0.5f, -0.5f, 0.0f,  0.0f, 1.0f, 0.0f,
     0.5f, -0.5f, 0.0f,  0.0f, 0.0f, 1.0f,
};

unsigned int VAO, VBO;
glGenVertexArrays(1, &VAO);
glGenBuffers(1, &VBO);

glBindVertexArray(VAO);
glBindBuffer(GL_ARRAY_BUFFER, VBO);
glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

// position attribute (location = 0)
glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
glEnableVertexAttribArray(0);

// color attribute (location = 1)
glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float),
                       (void*)(3 * sizeof(float)));
glEnableVertexAttribArray(1);
```

The VAO remembers *how* to interpret the raw bytes in the VBO. Each vertex
here is 6 floats: 3 for position, 3 for color. `glVertexAttribPointer` is
telling OpenGL "attribute 0 starts at byte 0, attribute 1 starts at byte
12, both stride 24 bytes apart."

### d) Shaders (GLSL)

Vertex shader — runs per vertex, must set `gl_Position`:

```glsl
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aColor;

out vec3 vertexColor;

void main() {
    gl_Position = vec4(aPos, 1.0);
    vertexColor = aColor;
}
```

Fragment shader — runs per pixel, must set the output color:

```glsl
#version 330 core
in vec3 vertexColor;
out vec4 FragColor;

void main() {
    FragColor = vec4(vertexColor, 1.0);
}
```

`vertexColor` is interpolated automatically across the triangle's surface
between the three vertices — that's why you get a smooth gradient for
free, no extra code.

### e) Compiling & linking shaders into a program

```cpp
unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
glShaderSource(vertexShader, 1, &vertexSrc, nullptr);
glCompileShader(vertexShader);
// (check compile status — see main.cpp for full error-checking)

unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
glShaderSource(fragmentShader, 1, &fragmentSrc, nullptr);
glCompileShader(fragmentShader);

unsigned int shaderProgram = glCreateProgram();
glAttachShader(shaderProgram, vertexShader);
glAttachShader(shaderProgram, fragmentShader);
glLinkProgram(shaderProgram);

glDeleteShader(vertexShader);
glDeleteShader(fragmentShader);
```

### f) The render loop

```cpp
while (!glfwWindowShouldClose(window)) {
    glClearColor(0.1f, 0.1f, 0.15f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glUseProgram(shaderProgram);
    glBindVertexArray(VAO);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    glfwSwapBuffers(window);
    glfwPollEvents();
}
```

Every frame: clear the screen, activate your shader program, bind the VAO
(which brings its attribute setup with it), issue the draw call, then
swap the front/back buffers (double buffering — you draw off-screen,
then present).

---

## 5. Where to go next, in order

1. **Uniforms** — pass data from CPU to shader per-frame (e.g. a time
   value, a color you control from a slider) via `glUniform*` and
   `glGetUniformLocation`.
2. **Transforms with GLM** — model/view/projection matrices, `glm::mat4`,
   `glm::perspective`, `glm::lookAt`. This is how you go from a static 2D
   triangle to a movable 3D camera.
3. **Textures** — load an image (stb_image.h is the standard lightweight
   loader), upload it with `glTexImage2D`, sample it in the fragment
   shader with `texture(sampler, uv)`.
4. **Element Buffer Objects (EBO)** — draw indexed geometry so shared
   vertices (like the corners of a cube) aren't duplicated.
5. **Depth testing** (`glEnable(GL_DEPTH_TEST)`) — required once you have
   overlapping 3D geometry.
6. **Lighting** — Phong/Blinn-Phong shading model, normals as a third
   vertex attribute.
7. Once OpenGL's pipeline feels intuitive, that's when **Vulkan** starts
   to make sense — it's the same pipeline, but every implicit step
   OpenGL hides from you (memory allocation, synchronization, command
   buffers) becomes explicit. Worth learning OpenGL first; Vulkan will
   be considerably less painful once this mental model is second nature.

## 6. Good references
- learnopengl.com — the de facto standard tutorial, code maps almost
  1:1 to what's here
- docs.gl — quick reference for what each `gl*` function actually does
- `man glVertexAttribPointer` style docs via `pacman -S opengl-man-pages`
  are also installable locally if you prefer offline man pages
